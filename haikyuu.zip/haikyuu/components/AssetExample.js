import { Text, View, StyleSheet, Image, Button } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      
       <Image style={styles.logo} source={require('../assets/foto3.webp')} />
       <Text style={styles.paragraph}>
        
      </Text>
      <Image style={styles.logo} source={require('../assets/foto1.webp')} />
<Text style={styles.paragraph}>
        
      </Text>
      <Button
      title='novos episódios'
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: '#808080',
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 128,
    width: 128,
  }
});
