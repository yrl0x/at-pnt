import { Text, View, StyleSheet, Image, Button } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Button
      title='novos episódios'
      />
    </View>
  );
}